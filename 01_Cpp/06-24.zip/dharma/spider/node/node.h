#ifndef SPIDER_NODE_NODE_H_
#define SPIDER_NODE_NODE_H_

namespace spider {
class Node {
public:
  Node(/* args */);
  virtual ~Node();
};

} // namespace spider

#endif